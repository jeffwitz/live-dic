import struct,time
from pathlib import Path
import numpy as np
from live_dic_frontier import FrontierPyramid
from gpu_spatial_seed import GpuSpatialPyramid
from lucas_kanade_icgn.roi import prepare_roi

class CollectorPyramid(FrontierPyramid):
 def prepare_research(self,reference,**kwargs):
  GpuSpatialPyramid.prepare_research(self,reference,**kwargs)
  device,wgpu=self.device,self._wgpu
  spatial=device.create_shader_module(code=Path('/tmp/live-dic-night-collector-spatial.wgsl').read_text())
  solver=device.create_shader_module(code=Path('/tmp/live-dic-night-collector-icgn.wgsl').read_text())
  def allocate(size):
   b=device.create_buffer(size=size,usage=wgpu.BufferUsage.STORAGE|wgpu.BufferUsage.COPY_DST|wgpu.BufferUsage.COPY_SRC|wgpu.BufferUsage.INDIRECT);self.research_resources.append(b);return b
  def data(value,usage):
   b=device.create_buffer_with_data(data=value,usage=usage);self.research_resources.append(b);return b
  def buffer(k,v):return self._buffer_resource(k,v)
  def pipeline(module,name,constants=None):return device.create_compute_pipeline(layout='auto',compute=dict(module=module,entry_point=name,**({'constants':constants}if constants else {})))
  def group(p,entries):return device.create_bind_group(layout=p.get_bind_group_layout(0),entries=entries)
  for level,slot,r in zip(self._levels,self._full_slots[0].level_slots,self.research,strict=True):
   n=level.grid_width*level.grid_height;failed=allocate((n+4)*4)
   constants={'MOTION_MODEL':1,'SUBSET_SIZE':self.subset_size,'SUBSET_STRIDE':self.subset_stride,'SOLVER_WORKGROUP_SIZE':self.solver_workgroup_size,'ROI_ENABLED':int(level.roi is not None and level.roi.effective)}
   base=[{'binding':0,'resource':slot.source_texture.create_view()},*[buffer(k,slot.buffers[name])for k,name in ((1,'config'),(2,'temporary'),(4,'reference'),(6,'metadata'),(7,'state'))],buffer(12,failed)]
   zero=pipeline(solver,'solve_collect',constants);zero_group=group(zero,base)
   seeded=pipeline(solver,'solve_seeded_collect',constants);seeded_group=group(seeded,base+[buffer(10,slot.buffers['seed_state']),buffer(11,slot.buffers['active_mask'])])
   plan=level.roi or prepare_roi(np.ones((level.height,level.width),bool),self.subset_size,self.subset_stride)
   links=plan.neighbour_bits.copy();links[~(plan.selected&level.reference_valid)]=0
   permissions=data(links,wgpu.BufferUsage.STORAGE)
   cfg=data(struct.pack('<8I4f',level.width,level.height,level.grid_width,n,self.subset_size,self.subset_stride,self.sample_step,0,self.min_gain,1e-3,0,0),wgpu.BufferUsage.UNIFORM)
   choose=pipeline(spatial,'choose_compact',{'FAILED_ONLY':True,'CANDIDATE_MODE':0})
   choose_group=group(choose,[{'binding':0,'resource':r['reference'].create_view()},{'binding':1,'resource':slot.source_texture.create_view()},*[buffer(k,v)for k,v in ((2,cfg),(3,slot.buffers['state']),(4,permissions),(5,slot.buffers['seed_state']),(6,r['work']),(7,r['scores']),(8,r['prior']),(10,failed))]])
   finalize=pipeline(spatial,'finalize_compact_chain');finalize_group=group(finalize,[buffer(k,v)for k,v in ((6,r['work']),(9,r['continuation']),(10,failed))])
   r.update(failed=failed,collect_zero=zero,collect_zero_group=zero_group,collect_seeded=seeded,collect_seeded_group=seeded_group,collect_choose=choose,collect_choose_group=choose_group,collect_finalize=finalize,collect_finalize_group=finalize_group)
 def _encode_frontier(self,encoder,level,slot,r):
  for step in range(self.passes):
   encoder.clear_buffer(r['work']);compute=encoder.begin_compute_pass()
   compute.set_pipeline(r['collect_choose']);compute.set_bind_group(0,r['collect_choose_group']);compute.dispatch_workgroups_indirect(r['failed']if step==0 else r['continuation'],4 if step==0 else 0)
   compute.set_pipeline(r['collect_finalize']);compute.set_bind_group(0,r['collect_finalize_group']);compute.dispatch_workgroups(1)
   compute.set_pipeline(r['compact']);compute.set_bind_group(0,r['compact_group']);compute.dispatch_workgroups_indirect(r['work'],4);compute.end()
   if self.capture_counts:encoder.copy_buffer_to_buffer(r['work'],0,r['diagnostics'],step*16,16);self._counts_ready=True
 def _encode_slot(self, slot):
     if not self.use_frontier:
         return super()._encode_slot(slot)
     started = time.perf_counter()
     self._counts_ready = False
     encoder = self.device.create_command_encoder(label="GPU spatial seed research")
     for level_slot in slot.level_slots:
         encoder.clear_buffer(level_slot.buffers["state"])
     for r in self.research:
         encoder.clear_buffer(r["failed"])
     if self.has_affine_prior:
         coarse_slot = slot.level_slots[-1]
         prior = self.research[-1]["prior"]
         encoder.copy_buffer_to_buffer(
             prior, 0, coarse_slot.buffers["seed_state"], 0, prior.size
         )
     compute = encoder.begin_compute_pass()
     self._encode_reductions(encoder, slot.reduction_edges, compute_pass=compute)
     for index in range(self.pyramid_levels - 1, -1, -1):
         level = self._levels[index]
         level_slot = slot.level_slots[index]
         r = self.research[index]
         if index < self.pyramid_levels - 1:
             edge = slot.seed_edges[index]
             compute.set_pipeline(
                 self._roi_seed_pipeline
                 if index in self._roi_link_buffers
                 else self._seed_pipeline
             )
             compute.set_bind_group(
                 2,
                 self.median_edges[index]
                 if self.strategy in ("median", "spatial-median", "seed-median")
                 else edge.bind_group,
             )
             compute.dispatch_workgroups((edge.destination_count + 255) // 256)
         seeded = index < self.pyramid_levels - 1 or self.has_affine_prior
         level._encode_registration_passes(
             encoder,
             level_slot,
             r["collect_seeded"] if seeded else r["collect_zero"],
             solver_bind_group=r["collect_seeded_group"] if seeded else r["collect_zero_group"],
             compute_pass=compute,
         )
         compute.end()
         self._encode_frontier(encoder, level, level_slot, r)
         if index > 0 and self.strategy == "seed-median":
             encoder.copy_buffer_to_buffer(
                 level_slot.buffers["state"], 0, r["snapshot"], 0, r["snapshot"].size
             )
         compute = encoder.begin_compute_pass()
         if index > 0 and self.strategy == "seed-median":
             compute.set_pipeline(r["seed_median"])
             compute.set_bind_group(0, r["seed_median_group"])
             compute.dispatch_workgroups((level.grid_width * level.grid_height + 63) // 64)
         elif index > 0 and self.strategy in ("median", "spatial-median"):
             compute.set_pipeline(r["median"])
             compute.set_bind_group(0, level_slot.bind_group)
             compute.dispatch_workgroups((level.grid_width * level.grid_height + 255) // 256)
     compute.end()
     fine = slot.level_slots[0]
     encoder.copy_buffer_to_buffer(
         fine.buffers["state"], 0, fine.readback, 0, fine.readback.size
     )
     return encoder.finish(), (time.perf_counter() - started) * 1000
