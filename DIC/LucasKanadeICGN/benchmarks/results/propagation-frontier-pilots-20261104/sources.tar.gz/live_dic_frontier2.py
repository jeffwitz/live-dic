import struct
from pathlib import Path
import numpy as np
from live_dic_frontier import FrontierPyramid
from gpu_spatial_seed import GpuSpatialPyramid
from lucas_kanade_icgn.roi import prepare_roi

class Frontier2Pyramid(FrontierPyramid):
 def prepare_research(self, reference, **kwargs):
  GpuSpatialPyramid.prepare_research(self,reference,**kwargs)
  device,wgpu=self.device,self._wgpu
  spatial=device.create_shader_module(code=Path('/tmp/live-dic-night-frontier2.wgsl').read_text())
  def allocate(size):
   b=device.create_buffer(size=size,usage=wgpu.BufferUsage.STORAGE|wgpu.BufferUsage.COPY_DST|wgpu.BufferUsage.COPY_SRC|wgpu.BufferUsage.INDIRECT);self.research_resources.append(b);return b
  def data(value,usage):
   b=device.create_buffer_with_data(data=value,usage=usage);self.research_resources.append(b);return b
  def buffer(k,v):return self._buffer_resource(k,v)
  def pipeline(module,name,constants):return device.create_compute_pipeline(layout='auto',compute=dict(module=module,entry_point=name,constants=constants))
  def group(p,entries):return device.create_bind_group(layout=p.get_bind_group_layout(0),entries=entries)
  for level,slot,r in zip(self._levels,self._full_slots[0].level_slots,self.research,strict=True):
   n=level.grid_width*level.grid_height
   fronts=[allocate((2*n+4)*4)for _ in range(2)]
   plan=level.roi or prepare_roi(np.ones((level.height,level.width),bool),self.subset_size,self.subset_stride)
   links=plan.neighbour_bits.copy();links[~(plan.selected&level.reference_valid)]=0
   permissions=data(links,wgpu.BufferUsage.STORAGE)
   cfg=data(struct.pack('<8I4f',level.width,level.height,level.grid_width,n,self.subset_size,self.subset_stride,self.sample_step,0,self.min_gain,1e-3,0,0),wgpu.BufferUsage.UNIFORM)
   common=[{'binding':0,'resource':r['reference'].create_view()},{'binding':1,'resource':slot.source_texture.create_view()},*[buffer(k,v)for k,v in ((2,cfg),(3,slot.buffers['state']),(4,permissions),(5,slot.buffers['seed_state']),(6,r['work']),(7,r['scores']),(8,r['prior']))]]
   choose=pipeline(spatial,'choose_fused',{'FAILED_ONLY':True,'CANDIDATE_MODE':0})
   choose_group=group(choose,common)
   front_choose=pipeline(spatial,'choose_fused_frontier',{'FAILED_ONLY':True,'CANDIDATE_MODE':0})
   front_groups=[group(front_choose,common+[buffer(10,b)])for b in fronts]
   mark=pipeline(spatial,'mark_frontier',{})
   mark_groups=[group(mark,[buffer(2,cfg),buffer(11,b),buffer(12,r['work'])])for b in fronts]
   r.update(fronts=fronts,fused_choose=choose,fused_choose_group=choose_group,fused_front_choose=front_choose,fused_front_groups=front_groups,front_mark=mark,front_mark_groups=mark_groups,front_diagnostics=allocate(self.passes*16))
 def _encode_frontier(self,encoder,level,slot,r):
  for step in range(self.passes):
   encoder.clear_buffer(r['work'])
   emit=step+1<self.passes
   if emit:encoder.clear_buffer(r['fronts'][step%2])
   compute=encoder.begin_compute_pass()
   if step==0:
    compute.set_pipeline(r['fused_choose']);compute.set_bind_group(0,r['fused_choose_group']);compute.dispatch_workgroups(level.grid_width,level.grid_height)
   else:
    which=(step-1)%2;compute.set_pipeline(r['fused_front_choose']);compute.set_bind_group(0,r['fused_front_groups'][which]);compute.dispatch_workgroups_indirect(r['fronts'][which],4)
   compute.set_pipeline(r['compact']);compute.set_bind_group(0,r['compact_group']);compute.dispatch_workgroups_indirect(r['work'],4)
   if emit:
    compute.set_pipeline(r['front_mark']);compute.set_bind_group(0,r['front_mark_groups'][step%2]);compute.dispatch_workgroups_indirect(r['work'],4)
   compute.end()
   if self.capture_counts:
    encoder.copy_buffer_to_buffer(r['work'],0,r['diagnostics'],step*16,16);self._counts_ready=True
    if emit:encoder.copy_buffer_to_buffer(r['fronts'][step%2],0,r['front_diagnostics'],step*16,16)
