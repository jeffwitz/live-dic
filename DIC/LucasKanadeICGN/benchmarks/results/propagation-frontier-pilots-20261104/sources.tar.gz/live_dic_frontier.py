import struct,time
from pathlib import Path
from unittest.mock import patch
import numpy as np
import wgpu.backends.wgpu_native._api as api
from gpu_spatial_seed import GpuSpatialPyramid
from lucas_kanade_icgn.roi import prepare_roi

class FrontierPyramid(GpuSpatialPyramid):
    def __init__(self,*,frontier=True,**kwargs):
        self.use_frontier=frontier
        super().__init__(strategy="spatial",failed_only=True,stop_when_unchanged=True,**kwargs)
    def prepare_research(self,reference,**kwargs):
        source=Path("/tmp/live-dic-night-frontier.wgsl").read_text()
        original=api.GPUDevice.create_shader_module
        def override(device,**options):
            if "Experimental translation seed selection" in options.get("code",""):options["code"]=source
            return original(device,**options)
        with patch.object(api.GPUDevice,"create_shader_module",override):
            super().prepare_research(reference,**kwargs)
        device,wgpu=self.device,self._wgpu
        module=device.create_shader_module(code=source)
        def allocate(n,usage):
            b=device.create_buffer(size=n,usage=usage);self.research_resources.append(b);return b
        def data(value,usage):
            b=device.create_buffer_with_data(data=value,usage=usage);self.research_resources.append(b);return b
        def buffer(binding,value):return self._buffer_resource(binding,value)
        def pipeline(name,constants=None):
            return device.create_compute_pipeline(layout="auto",compute={"module":module,"entry_point":name,**({"constants":constants}if constants else {})})
        def group(p,entries):return device.create_bind_group(layout=p.get_bind_group_layout(0),entries=entries)
        for level,slot,r in zip(self._levels,self._full_slots[0].level_slots,self.research,strict=True):
            n=level.grid_width*level.grid_height
            storage=wgpu.BufferUsage.STORAGE|wgpu.BufferUsage.COPY_DST|wgpu.BufferUsage.COPY_SRC
            front=allocate((n+4)*4,storage|wgpu.BufferUsage.INDIRECT)
            flags=allocate(n*4,storage)
            plan=level.roi or prepare_roi(np.ones((level.height,level.width),bool),self.subset_size,self.subset_stride)
            links=plan.neighbour_bits.copy();links[~(plan.selected&level.reference_valid)]=0
            permissions=data(links,wgpu.BufferUsage.STORAGE)
            cfg=data(struct.pack("<8I4f",level.width,level.height,level.grid_width,n,self.subset_size,self.subset_stride,self.sample_step,0,self.min_gain,1e-3,0,0),wgpu.BufferUsage.UNIFORM)
            choose=pipeline("choose_frontier",{"FAILED_ONLY":True,"CANDIDATE_MODE":0})
            choose_group=group(choose,[{"binding":0,"resource":r["reference"].create_view()},{"binding":1,"resource":slot.source_texture.create_view()},*[buffer(k,v)for k,v in ((2,cfg),(3,slot.buffers["state"]),(4,permissions),(5,slot.buffers["seed_state"]),(6,r["work"]),(7,r["scores"]),(8,r["prior"]),(10,front))]])
            produce=pipeline("finalize_frontier_work")
            produce_group=group(produce,[buffer(k,v)for k,v in ((2,cfg),(6,r["work"]),(9,r["continuation"]),(11,front))])
            clear=pipeline("clear_frontier_flags");clear_group=group(clear,[buffer(2,cfg),buffer(12,flags)])
            mark=pipeline("mark_frontier");mark_group=group(mark,[buffer(k,v)for k,v in ((2,cfg),(3,slot.buffers["state"]),(4,permissions),(11,front),(12,flags),(13,r["work"]))])
            finalize=pipeline("finalize_frontier");finalize_group=group(finalize,[buffer(11,front)])
            diag=allocate(self.passes*16,wgpu.BufferUsage.COPY_SRC|wgpu.BufferUsage.COPY_DST)
            r.update(front=front,flags=flags,front_choose=choose,front_choose_group=choose_group,front_produce=produce,front_produce_group=produce_group,front_clear=clear,front_clear_group=clear_group,front_mark=mark,front_mark_group=mark_group,front_finalize=finalize,front_finalize_group=finalize_group,front_diagnostics=diag)
    def _encode_frontier(self,encoder,level,slot,r):
        for step in range(self.passes):
            encoder.clear_buffer(r["work"])
            compute=encoder.begin_compute_pass()
            if step==0:
                compute.set_pipeline(r["choose"]);compute.set_bind_group(0,r["choose_group"])
                compute.dispatch_workgroups(level.grid_width,level.grid_height)
            else:
                compute.set_pipeline(r["front_choose"]);compute.set_bind_group(0,r["front_choose_group"])
                compute.dispatch_workgroups_indirect(r["front"],4)
            compute.set_pipeline(r["front_produce"]);compute.set_bind_group(0,r["front_produce_group"]);compute.dispatch_workgroups(1)
            compute.set_pipeline(r["compact"]);compute.set_bind_group(0,r["compact_group"]);compute.dispatch_workgroups_indirect(r["work"],4)
            compute.end()
            if self.capture_counts:
                encoder.copy_buffer_to_buffer(r["work"],0,r["diagnostics"],step*16,16);self._counts_ready=True
            if step+1<self.passes:
                compute=encoder.begin_compute_pass()
                compute.set_pipeline(r["front_clear"]);compute.set_bind_group(0,r["front_clear_group"]);compute.dispatch_workgroups_indirect(r["continuation"],0)
                compute.set_pipeline(r["front_mark"]);compute.set_bind_group(0,r["front_mark_group"]);compute.dispatch_workgroups_indirect(r["work"],4)
                compute.set_pipeline(r["front_finalize"]);compute.set_bind_group(0,r["front_finalize_group"]);compute.dispatch_workgroups_indirect(r["continuation"],0)
                compute.end()
                if self.capture_counts:encoder.copy_buffer_to_buffer(r["front"],0,r["front_diagnostics"],step*16,16)

    def _encode_slot(self, slot):
        if not self.use_frontier:
            return super()._encode_slot(slot)
        started = time.perf_counter()
        self._counts_ready = False
        encoder = self.device.create_command_encoder(label="GPU spatial seed research")
        for level_slot in slot.level_slots:
            encoder.clear_buffer(level_slot.buffers["state"])
        if self.has_affine_prior:
            coarse_slot = slot.level_slots[-1]
            prior = self.research[-1]["prior"]
            encoder.copy_buffer_to_buffer(
                prior, 0, coarse_slot.buffers["seed_state"], 0, prior.size
            )
        compute = encoder.begin_compute_pass()
        self._encode_reductions(encoder, slot.reduction_edges, compute_pass=compute)
        for index in range(self.pyramid_levels - 1, -1, -1):
            level = self._levels[index]
            level_slot = slot.level_slots[index]
            r = self.research[index]
            if index < self.pyramid_levels - 1:
                edge = slot.seed_edges[index]
                compute.set_pipeline(
                    self._roi_seed_pipeline
                    if index in self._roi_link_buffers
                    else self._seed_pipeline
                )
                compute.set_bind_group(
                    2,
                    self.median_edges[index]
                    if self.strategy in ("median", "spatial-median", "seed-median")
                    else edge.bind_group,
                )
                compute.dispatch_workgroups((edge.destination_count + 255) // 256)
            seeded = index < self.pyramid_levels - 1 or self.has_affine_prior
            level._encode_registration_passes(
                encoder,
                level_slot,
                level._seeded_solver if seeded else level._portable_solver,
                solver_bind_group=level_slot.seeded_bind_group if seeded else level_slot.bind_group,
                compute_pass=compute,
            )
            compute.end()
            self._encode_frontier(encoder, level, level_slot, r)
            if index > 0 and self.strategy == "seed-median":
                encoder.copy_buffer_to_buffer(
                    level_slot.buffers["state"], 0, r["snapshot"], 0, r["snapshot"].size
                )
            compute = encoder.begin_compute_pass()
            if index > 0 and self.strategy == "seed-median":
                compute.set_pipeline(r["seed_median"])
                compute.set_bind_group(0, r["seed_median_group"])
                compute.dispatch_workgroups((level.grid_width * level.grid_height + 63) // 64)
            elif index > 0 and self.strategy in ("median", "spatial-median"):
                compute.set_pipeline(r["median"])
                compute.set_bind_group(0, level_slot.bind_group)
                compute.dispatch_workgroups((level.grid_width * level.grid_height + 255) // 256)
        compute.end()
        fine = slot.level_slots[0]
        encoder.copy_buffer_to_buffer(
            fine.buffers["state"], 0, fine.readback, 0, fine.readback.size
        )
        return encoder.finish(), (time.perf_counter() - started) * 1000

