from pathlib import Path
import os,subprocess
root=Path('/home/jeff/Code/tests_gpuio');python=root/'DIC/LucasKanadeICGN/python/.venv/bin/python'
command=[str(python),'/tmp/live_dic_workgroup_pilot.py','--width','32','--rounds','180','--repeats','100','--output','/tmp/live-dic-native-width-extended']
with Path('/tmp/live-dic-native-width-extended.log').open('x') as log:
 process=subprocess.Popen(command,cwd=root,env={**os.environ,'PYTHONPATH':str(root/'DIC/LucasKanadeICGN/python/src')},stdout=log,stderr=subprocess.STDOUT)
 observer=subprocess.Popen(['python3',str(root/'DIC/LucasKanadeICGN/benchmarks/monitor_linux_process.py'),'--pid',str(process.pid),'--max-seconds','1200','--output','/tmp/live-dic-native-width-extended-monitor'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 Path('/tmp/live-dic-native-width-extended-process.json').write_text(__import__('json').dumps({'pid':process.pid,'observerPid':observer.pid,'command':command}))
 assert process.wait()==0
 assert observer.wait()==0
