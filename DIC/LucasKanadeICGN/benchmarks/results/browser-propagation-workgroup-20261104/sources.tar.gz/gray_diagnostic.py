"""Paired resident-ImageBitmap-to-typed-field browser width pilot."""
import argparse,csv,hashlib,json,subprocess,sys,time,shutil
from pathlib import Path
from urllib.parse import quote
from lucas_kanade_icgn import ICGNWebGL
from lucas_kanade_icgn.engine import _StaticServer
ROOT=Path('/home/jeff/Code/tests_gpuio')
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--site',type=Path,required=True);p.add_argument('--width',type=int,choices=(16,32),required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(exist_ok=False)
assets=ROOT/'DIC/LucasKanadeICGN/assets/uhd_tensile'
for old,new in [('reference.png','width-reference.png'),('frame_040.png','width-frame.png')]:shutil.copyfile(assets/old,a.site/'demo'/new)
(a.site/'width-pilot.html').write_text('<!doctype html><meta charset="utf-8"><title>Controlled width pilot</title>')
with (assets/'machine_truth.csv').open() as stream:truth=next(r for r in csv.DictReader(stream)if int(r['frame'])==40)
server=_StaticServer(a.site.resolve().parent);server.start()
try:
 with ICGNWebGL(backend='webgpu-wgsl',call_timeout=300) as browser:
  browser._evaluate(f"location.assign({json.dumps(f'http://127.0.0.1:{server.port}/{quote(a.site.name)}/width-pilot.html')});true")
  for _ in range(100):
   if browser._evaluate("document.title==='Controlled width pilot'&&document.readyState==='complete'"):break
   time.sleep(.05)
  body=r'''(async()=>{
    const {DICEngine}=await import('./web/core/engine.js');
    const image=async name=>createImageBitmap(await(await fetch('./demo/'+name)).blob());
    const f=await image('width-reference.png'),g=await image('width-frame.png');
    const canvas=new OffscreenCanvas(g.width,g.height),context=canvas.getContext('2d');context.drawImage(g,0,0);
    const pixels=context.getImageData(0,0,g.width,g.height).data,gray=Uint8Array.from({length:g.width*g.height},(_,i)=>pixels[i*4]);
    const adapter=await navigator.gpu.requestAdapter({powerPreference:'high-performance'});
    const device=await adapter.requestDevice({requiredLimits:{maxStorageBuffersPerShaderStage:8}});
    const errors=[];device.addEventListener('uncapturederror',event=>errors.push(event.error.message));
    const engines=[],fields=[],rows=[],timings=[[],[]];
    const check=(ok,message)=>{if(!ok)throw new Error(message);};
    function quality(r){
      let n=0,population=0,squared=0,gradient=0;const errors=[];
      for(let i=0;i<r.status.length;i++){
        const x=i%r.grid[0]*16+15.5,y=Math.floor(i/r.grid[0])*16+15.5;
        for(const c of [1,2,4,5])gradient=Math.max(gradient,Math.abs(r.parameters[i*6+c]));
        if(x<32||x>=3808||y<32||y>=2128)continue;population++;
        if(r.status[i]<=.5)continue;n++;
        const error=Math.hypot(r.parameters[i*6]-(__STRETCH_X__-1)*(x-1920),r.parameters[i*6+3]-(__STRETCH_Y__-1)*(y-1080));
        squared+=error*error;errors.push(error);
      }
      errors.sort((a,b)=>a-b);const q={population,accepted:r.accepted,coverage:n/population,vectorRmse:Math.sqrt(squared/n),p95Error:errors[Math.floor(.95*(errors.length-1))],gradient};
      check(q.coverage>=.995&&q.vectorRmse<.01518230373115895&&q.p95Error<.02722860762111737&&gradient===0,'Analytical gate failed: '+JSON.stringify(q));
      check(r.parameters.every(Number.isFinite),'Nonfinite field');return q;
    }
    try{
      for(const width of [16,__WIDTH__]){
        const e=await DICEngine.create({device,solverWorkgroupSize:width,motionModel:'translation',subsetSize:32,subsetStride:16,
          pyramidLevels:2,iterationsPerLevel:[8,16],tolerancePerLevel:[.005,.005],spatialPropagationPasses:2,outlierPolicy:'disabled',readback:'full'});
        engines.push(e);await e.setReference(f);
        let r;for(let k=0;k<8;k++)r=await e.register(gray);fields.push(r);rows.push({width,config:r.config,quality:quality(r),lastTiming:r.timing});
      }
      let maximum=0,statusMismatch=0,iterationDifferences=0;
      for(let i=0;i<fields[0].parameters.length;i++)maximum=Math.max(maximum,Math.abs(fields[0].parameters[i]-fields[1].parameters[i]));
      for(let i=0;i<fields[0].status.length;i++){statusMismatch+=+(fields[0].status[i]!==fields[1].status[i]);iterationDifferences+=+(fields[0].iterations[i]!==fields[1].iterations[i]);}
      check(maximum<.001&&statusMismatch===0,'Width parity gate failed '+JSON.stringify({maximum,statusMismatch}));
      for(let round=0;round<1;round++){
        const samples=[[],[]];
        for(let k=0;k<8;k++)for(const e of engines)await e.register(gray);
        for(let pair=0;pair<20;pair++)for(const index of ((round+pair)%2?[1,0]:[0,1])){
          const start=performance.now(),r=await engines[index].register(gray);samples[index].push(performance.now()-start);
          check(r.accepted===fields[index].accepted,'Acceptance changed');
        }
        for(let i=0;i<2;i++)timings[i].push(samples[i]);
      }
      check(errors.length===0,'WebGPU validation error '+errors.join(';'));
      return {adapter:{vendor:adapter.info.vendor,architecture:adapter.info.architecture,device:adapter.info.device,description:adapter.info.description},limits:{...Object.fromEntries(['maxStorageBuffersPerShaderStage','maxBufferSize','maxStorageBufferBindingSize','maxComputeWorkgroupStorageSize','maxComputeInvocationsPerWorkgroup'].map(k=>[k,device.limits[k]]))},rows,timings,maximum,statusMismatch,iterationDifferences,errors};
    }finally{for(const e of engines)e.destroy();f.close();g.close();device.destroy();}
  })()'''.replace('__WIDTH__',str(a.width)).replace('__STRETCH_X__',truth['stretch_x']).replace('__STRETCH_Y__',truth['stretch_y'])
  report=browser._evaluate(body)
  report.update(command=[sys.executable,*sys.argv],sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),sourceDirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)),scriptSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputSha256={name:hashlib.sha256((assets/name).read_bytes()).hexdigest()for name in ['reference.png','frame_040.png']},build=json.loads((a.site/'build.json').read_text()),boundary='diagnostic: resident Uint8Array gray target to full typed field; excludes one-time Bitmap decode/gray extraction, reference preparation, display, storage and Python/CDP round trips',schedule='Diagnostic only: two engines on one injected device, one 20-pair AB/BA block; not a qualified percentile campaign')
  (a.output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
  print(json.dumps({k:report[k]for k in ['adapter','maximum','statusMismatch','iterationDifferences','rows']},indent=2))
finally:server.close()
