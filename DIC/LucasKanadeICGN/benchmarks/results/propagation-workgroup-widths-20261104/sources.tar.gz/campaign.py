"""Sequential paired width controls; no tests/builds should run alongside."""
from pathlib import Path
import hashlib,json,subprocess,sys
import numpy as np
root=Path('/home/jeff/Code/tests_gpuio');output=Path('/tmp/live-dic-width-controls');output.mkdir(exist_ok=False)
script=Path('/tmp/live_dic_workgroup_pilot.py');digest=hashlib.sha256(script.read_bytes()).hexdigest()
criteria=dict(scriptSha256=digest,rounds=12,repeats=100,schedule='one prepared device, per-frame AB/BA; only existing solver workgroup overrides change',referenceMargin='95th percentile of absolute per-block median paired reference/reference differences; derived and written before candidates',bootstrapSamples=10000,bootstrapSeed=1729,parameterMaxAbsDifference=0.001,coverageMinimum=.995,vectorRmseMaximum=.01518230373115895,p95ErrorMaximum=.02722860762111737,statusAgreement='exact',iterationAgreement='reported, not forced when floating reductions change',cases={})
def write():
 (output/'criteria.json').write_text(json.dumps(criteria,indent=2,allow_nan=False)+'\n')
write()
summary={}
for case,extra in [('tensile',[]),('seeded',['--seeded'])]:
 for width in [16,32,128]:
  assert hashlib.sha256(script.read_bytes()).hexdigest()==digest
  target=output/f'{case}-{width}'
  with (output/f'{case}-{width}.log').open('x') as log:
   command=[str(root/'DIC/LucasKanadeICGN/python/.venv/bin/python'),str(script),'--width',str(width),'--output',str(target),*extra]
   code=subprocess.call(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
  if code:
   (output/'failure.json').write_text(json.dumps(dict(case=case,width=width,exitCode=code,log=f'{case}-{width}.log'))+'\n')
   raise RuntimeError(f'{case}/{width} failed; retain its log')
  report=json.loads((target/'report.json').read_text());assert not report['sourceDirty']
  a,b=[np.array(row['samplesByRoundMs'])for row in report['rows']]
  paired=np.median(a-b,axis=1)
  if width==16:
   for name in ['parameters','status','iterations']:assert report['rows'][0]['fieldSha256'][name]==report['rows'][1]['fieldSha256'][name]
   criteria['cases'][case]=dict(referenceReportSha256=hashlib.sha256((target/'report.json').read_bytes()).hexdigest(),marginMs=float(np.percentile(np.abs(paired),95)))
   write()
  rng=np.random.default_rng(1729);samples=np.median(paired[rng.integers(0,len(paired),(10000,len(paired)))],axis=1)
  interval=np.percentile(samples,[2.5,97.5]);margin=criteria['cases'][case]['marginMs']
  record=dict(control=report['rows'][0]['statistics'],candidate=report['rows'][1]['statistics'],pairedBlockMedianSavingMs=float(np.median(paired)),saving95IntervalMs=interval.tolist(),referenceMarginMs=margin,improvementBeyondMargin=bool(interval[0]>margin),nonRegressionWithinMargin=bool(interval[0]>=-margin),quality=[row['quality']for row in report['rows']])
  summary[f'{case}-{width}']=record
  (output/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
  print(case,width,record['pairedBlockMedianSavingMs'],interval.tolist(),flush=True)
