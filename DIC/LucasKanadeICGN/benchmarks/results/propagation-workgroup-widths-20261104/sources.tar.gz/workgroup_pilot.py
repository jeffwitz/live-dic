"""Controlled solver-width pilot on one prepared propagation device.

Only existing SOLVER_WORKGROUP_SIZE overrides change. Scoring, budgets, images,
reference buffers and state bindings are shared. No production source is edited.
"""
import argparse,csv,hashlib,json,platform,subprocess,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path('/home/jeff/Code/tests_gpuio')
sys.path.insert(0,str(ROOT/'DIC/LucasKanadeICGN/benchmarks'))
from gpu_spatial_seed import GpuSpatialPyramid
from benchmark_spatial_chain import power_context
from benchmark_spatial_soak import statistics

def pipelines(engine,width):
    result=[]
    for level,r in zip(engine._levels,engine.research,strict=True):
        constants={**level._solver_constants(),'SOLVER_WORKGROUP_SIZE':width,'ROI_ENABLED':0}
        row=[]
        for entry,bgl in [('solve',level._bind_group_layout),('solve_seeded',level._seeded_bind_group_layout),('solve_compact_translation',level._seeded_bind_group_layout)]:
            layout=engine.device.create_pipeline_layout(bind_group_layouts=[bgl])
            row.append(engine.device.create_compute_pipeline(layout=layout,compute={'module':level._shader,'entry_point':entry,'constants':constants}))
        result.append(row)
    return result

def select(engine,variant,width):
    engine.solver_workgroup_size=width
    for level,r,(fresh,seeded,compact) in zip(engine._levels,engine.research,variant,strict=True):
        level.solver_workgroup_size=width
        level._portable_solver=fresh;level._seeded_solver=seeded;r['compact']=compact

def check(field,expected,truth):
    assert np.isfinite(field.parameters).all()
    assert not np.any(field.parameters[...,[1,2,4,5]])
    np.testing.assert_array_equal(field.status,expected.status)
    # Width changes reduction order. Fix a strict parameter agreement bound
    # before reading the candidate, in addition to the existing analytical gates.
    difference=float(np.max(np.abs(field.parameters-expected.parameters)))
    assert difference<0.001,difference
    y,x=np.indices(field.status.shape);x=x*16+15.5;y=y*16+15.5
    population=(x>=32)&(x<3808)&(y>=32)&(y<2128)
    valid=population&field.accepted_mask
    actual=field.parameters[...,[0,3]][valid]
    displacement=np.stack(((float(truth['stretch_x'])-1)*(x-1920),(float(truth['stretch_y'])-1)*(y-1080)),axis=-1)
    error=np.linalg.norm(actual-displacement[valid],axis=-1)
    quality=dict(coverage=float(valid.sum()/population.sum()),vectorRmse=float(np.sqrt(np.mean(error**2))),p95Error=float(np.percentile(error,95)),parameterMaxAbsDifference=difference,accepted=field.accepted,iterationDifferences=int(np.count_nonzero(field.iterations!=expected.iterations)))
    assert quality['coverage']>=.995 and quality['vectorRmse']<.01518230373115895 and quality['p95Error']<.02722860762111737,quality
    return quality

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--width',type=int,choices=[16,32,128],required=True);p.add_argument('--rounds',type=int,default=12);p.add_argument('--repeats',type=int,default=100);p.add_argument('--seeded',action='store_true');a=p.parse_args();a.output.mkdir(exist_ok=False)
    assets=ROOT/'DIC/LucasKanadeICGN/assets/uhd_tensile'
    f=np.array(Image.open(assets/'reference.png'));g=np.array(Image.open(assets/'frame_040.png'))
    with (assets/'machine_truth.csv').open() as stream:truth=next(row for row in csv.DictReader(stream) if int(row['frame'])==40)
    if a.seeded:g=np.roll(f,(-6,14),(0,1));truth['stretch_x']=truth['stretch_y']='1'
    report=dict(command=[sys.executable,*sys.argv],sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),sourceDirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)),scriptSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),platform=platform.platform(),boundary='resident NumPy target to materialized field/statistics; excludes preparation, decoding, display, storage and variant selection',case='seeded translation' if a.seeded else 'original tensile',width=a.width,rounds=a.rounds,repeats=a.repeats,**power_context(),rows=[])
    if a.seeded:
        # Use a separate constant truth representation without modifying input files.
        def qualify(field,expected):
            np.testing.assert_array_equal(field.status,expected.status)
            difference=float(np.max(np.abs(field.parameters-expected.parameters)));assert difference<.001,difference
            y,x=np.indices(field.status.shape);population=(x*16+15.5>=32)&(x*16+15.5<3808)&(y*16+15.5>=32)&(y*16+15.5<2128);valid=population&field.accepted_mask
            error=np.linalg.norm(field.parameters[...,[0,3]][valid]-[14,-6],axis=-1)
            q=dict(coverage=float(valid.sum()/population.sum()),vectorRmse=float(np.sqrt(np.mean(error**2))),p95Error=float(np.percentile(error,95)),parameterMaxAbsDifference=difference,accepted=field.accepted,iterationDifferences=int(np.count_nonzero(field.iterations!=expected.iterations)))
            assert np.isfinite(field.parameters).all() and not np.any(field.parameters[...,[1,2,4,5]])
            assert q['coverage']>=.995 and q['vectorRmse']<.01518230373115895 and q['p95Error']<.02722860762111737,q
            return q
    else:qualify=lambda field,expected:check(field,expected,truth)
    with GpuSpatialPyramid(strategy='spatial',failed_only=True,passes=2,stop_when_unchanged=True,device_type='gpu',subset_size=32,subset_stride=16,tolerance_per_level=(.005,.005)) as engine:
        engine.prepare_research(f)
        if a.seeded:
            for index,(level,slot) in enumerate(zip(engine._levels,engine._full_slots[0].level_slots,strict=True)):
                seed=np.zeros((level.grid_height,level.grid_width,8),np.float32);seed[...,0]=14/(1<<index);seed[...,3]=-6/(1<<index)
                if index==engine.pyramid_levels-1:
                    y,x=np.indices(seed.shape[:2]);bad=(x%8<3)&(y%8<3)&(x>3)&(y>3);seed[bad,0]=25;seed[bad,3]=-18
                engine.device.queue.write_buffer(engine.research[index]['prior'],0,seed)
                engine.device.queue.write_buffer(slot.buffers['seed_state'],0,seed)
            engine.has_affine_prior=True
        report['adapter']=engine.adapter_info;report['deviceLimits']=dict(engine.device.limits)
        original=[(l._portable_solver,l._seeded_solver,r['compact'])for l,r in zip(engine._levels,engine.research,strict=True)]
        variants=[original,pipelines(engine,a.width)]
        expected=engine.register(g)
        for index in range(2):
            select(engine,variants[index],16 if index==0 else a.width)
            for _ in range(8):field=engine.register(g)
            report['rows'].append(dict(width=16 if index==0 else a.width,quality=qualify(field,expected),configuration=dict(field.config),fieldSha256={name:hashlib.sha256(getattr(field,name).tobytes()).hexdigest() for name in ('parameters','status','iterations')},samplesByRoundMs=[]))
            engine.capture_counts=True;engine.register(g);report['rows'][-1]['workListsByLevel']=engine.read_diagnostics();engine.capture_counts=False
        for block in range(a.rounds):
            samples=[[],[]]
            for _ in range(8):
                for index in range(2):select(engine,variants[index],16 if index==0 else a.width);engine.register(g)
            for pair in range(a.repeats):
                for index in ((0,1)if(block+pair)%2==0 else(1,0)):
                    select(engine,variants[index],16 if index==0 else a.width)
                    start=time.perf_counter();field=engine.register(g);samples[index].append((time.perf_counter()-start)*1000)
                    assert field.accepted==expected.accepted
            for index in range(2):report['rows'][index]['samplesByRoundMs'].append(samples[index])
            qualify(field,expected)
        for row in report['rows']:row['statistics']=statistics(np.array(row['samplesByRoundMs']).ravel())
    (a.output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps([r['statistics']for r in report['rows']]))
if __name__=='__main__':main()
